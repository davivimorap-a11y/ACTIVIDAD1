codigo = input("Ingresa tu codigo de invitacion: ")
if ("codigo == VIP2024"):
    print("Bienvenido a la zona explusiva ")
else:
    print("Codigo invalido, acceso denegano a la zona VIP");

estatura = float(input("Ingrese su estatura en centímetros: "))

if estatura >= 140:
    print("Puedes subir a la montaña rusa")
else:
    print("No cumples con la estatura mínima requerida")
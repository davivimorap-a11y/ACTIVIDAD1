edad = int(input("Ingresa tu edad: "))
if (edad > 65):
    print("Tienes derecho al 20% de descuento")
else:
    print("Aplica a la tarifa plena sin descuento");
compra = float(input("Ingrese el monto total de la compra: "))

if compra >= 50:
    print("Envío gratis")
else:
    print("Se aplicará un cobro de envío de $5")
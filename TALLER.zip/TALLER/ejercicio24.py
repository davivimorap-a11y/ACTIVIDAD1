precio = float(input("Ingrese el valor del producto: "))
metodo = input("Ingrese el método de pago (Efectivo o Tarjeta): ").lower()

if metodo == "efectivo":
    total = precio * 0.90
    print("Total con descuento del 10%: $", total)
else:
    total = precio
    print("Total sin descuento: $", total)
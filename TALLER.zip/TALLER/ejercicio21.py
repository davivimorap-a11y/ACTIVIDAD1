contrasena = input("Ingrese la contraseña: ")

if contrasena == "1234segura":
    print("Acceso concedido")
else:
    print("Contraseña incorrecta")
membresia = input("Ingrese el estado de la membresía: ").lower()

if membresia == "activa":
    print("Acceso permitido a la plataforma")
else:
    print("Membresía inactiva, por favor renueve su suscripción")